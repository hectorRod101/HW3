package com.hector.hw2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TableRow;

import androidx.annotation.Nullable;

public class DBStudent extends SQLiteOpenHelper {

    // DB Name
    private static final String DB_NAME = "studentDB";

    // DB Table Name
    private static final String TABLE_NAME = "students";
    private static final String TABLE_NAME2 = "CourseEnrollment";

    // Columns inside student DB
    private static final String COL_1 = "FirstName";
    private static final String COL_2 = "LastName";
    private static final String COL_3 = "CWID";

    // Columns inside Course DB
    private static final String T_COL_1 = "Course";
    private static final String T_COL_2 = "Grade";
    private static final String T_COL_3 = "CWID";

    // Function creates DB
    public DBStudent(Context context){
        super(context, DB_NAME, null, 1);
        SQLiteDatabase db = this.getWritableDatabase();
    }



    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
       // String sqlStudents = "CREATE TABLE students(FirstName TEXT NOT NULL, LastName TEXT NOT NULL, CWID INTERGER NOT NULL UNIQUE, PRIMARY KEY(CWID))";
       // sqLiteDatabase.execSQL(sqlStudents);

        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME + " (FirstName TEXT NOT NULL, LastName TEXT NOT NULL, CWID INTEGER NOT NULL UNIQUE, PRIMARY KEY(CWID))");
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME2 + " (Course INTEGER, Grade TEXT, studentID INTEGER, FOREIGN KEY(studentID) REFERENCES students(CWID))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String sqlStudents = "DROP TABLE IF EXISTS " + TABLE_NAME;
        String sqlCourses = "DROP TABLE IF EXISTS " + TABLE_NAME2;


        sqLiteDatabase.execSQL(sqlStudents);
        sqLiteDatabase.execSQL(sqlCourses);

        onCreate(sqLiteDatabase);

    }

    // Function to insert data into student DB
    public boolean insertData(String firstName, String lastName, String nCWID){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cValues = new ContentValues();
        cValues.put(COL_1, firstName);
        cValues.put(COL_2, lastName);
        cValues.put(COL_3, nCWID);
        long result = db.insert(TABLE_NAME, null, cValues);
        if(result == -1)
            return false;
        else {
            return true;
        }
    }

    // Function to insert data into Course DB
    public boolean insertDataCourse(String course, String grade, String nCWID){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cValues = new ContentValues();
        cValues.put(T_COL_1, course);
        cValues.put(T_COL_2, grade);
        cValues.put(T_COL_3, nCWID);
        long result = db.insert(TABLE_NAME2, null, cValues);
        if(result == -1)
            return false;
        else {
            return true;
        }
    }


    // Function to update columns inside DB, needs valid CWID to be able to
    public boolean updateData(String firstName, String lastName, String nCWID) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cValues = new ContentValues();
        cValues.put(COL_1, firstName);
        cValues.put(COL_2, lastName);
        cValues.put(COL_3, nCWID);
        db.update(TABLE_NAME, cValues, "CWID = ?", new String[] {nCWID});
        return true;
    }

    // Function to delete data inside DB, needs valid CWID to be able to
    public Integer deleteData(String nCWID){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "CWID = ?", new String[]{nCWID});
    }

    // Function to get data from DB
    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLE_NAME, null);
        return res;
    }

}


