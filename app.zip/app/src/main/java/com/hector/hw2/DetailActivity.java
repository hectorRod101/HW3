// By: Hector Rodriguez Reyes
// Date: 11/05/19
// Class: CPSC 411
// Time: Tu/Th 4:00-5:15 PM

package com.hector.hw2;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.hector.hw2.model.CourseEnrollment;

import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity {

    // EditText First Name
    protected EditText firstText;

    // EditText Last Name
    protected EditText lastText;

    // EditText CWID
    protected EditText CWIDText;

    // EditText CourseID
    protected EditText courseText;

    // EditText Grade
    protected EditText gradeText;

    // Button DONE
    protected MenuItem enableMenuItem;

    protected Button buttonAdd;

    // Int for number of times ADD COURSE is clicked
    protected int clickCount =  0;

    // Instance of DB
    DBStudent myDB;

    protected LinearLayout root;

    protected String courseString;
    protected String gradeString;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_screen);

        // Initialize for Detail Activity
        myDB = new DBStudent(this);

        // Set Detail Activity's Title
        setTitle("Add Student");

        // Creates button to return to Main/Summary Activity
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Button for 'Add Course'
        buttonAdd = findViewById(R.id.addButton);

        // Get text IDs for inputs
        firstText = findViewById(R.id.editTextFirst);
        lastText = findViewById(R.id.editTextLast);
        CWIDText = findViewById(R.id.editTextID);
        courseText = findViewById(R.id.courseID);
        gradeText = findViewById(R.id.grade);

        // Set listeners
        firstText.addTextChangedListener(mTextWatcher);
        lastText.addTextChangedListener(mTextWatcher);
        CWIDText.addTextChangedListener(mTextWatcher);
        //courseText.addTextChangedListener(mTextWatcher);
        //gradeText.addTextChangedListener(mTextWatcher);

        // Layout to one new row to be appended
        root = findViewById(R.id.detailLayout);

        // Once user clicks on 'Add Course'
        // activity will output a new row
        // for user to input another Course ID and Grade
//        buttonAdd.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                getLayoutInflater().inflate(R.layout.course_list, root);
//                System.err.println(getLayoutInflater());
//            }
//        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createNewTextView();
            }
        });

    }


    private void createNewTextView() {
        View view = getLayoutInflater().inflate(R.layout.course_list, root);
                System.err.println(getLayoutInflater());

            // get the text from the EditText
            courseText = view.findViewById(R.id.courseID);
            String courseString = courseText.getText().toString().trim();

            gradeText = view.findViewById(R.id.grade);
            String gradeString = gradeText.getText().toString().trim();

            EditText cwidText = findViewById(R.id.editTextID);
            String cwidString = cwidText.getText().toString().trim();

            ArrayList<CourseEnrollment> courses = new ArrayList<>();
            courses.add(new CourseEnrollment(courseString,gradeString));

           // myDB.insertDataCourse(courseString, gradeString, cwidString);

    }


    // Create a return button to Main Activity
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }


    // Listens to user input in First Name, Last Name, CWID
    // Once all fields have been inserted it enables DONE button
    private TextWatcher mTextWatcher = new TextWatcher() {

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String firstString = firstText.getText().toString().trim();
            String lastString = lastText.getText().toString().trim();
            String CWIDString = CWIDText.getText().toString().trim();

            enableMenuItem.setEnabled(!firstString.isEmpty() && !lastString.isEmpty() && !CWIDString.isEmpty());

        }
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count,int after){}
        @Override
        public void afterTextChanged(Editable s) {}
    };


    // Create an action bar button DONE, UPDATE, DELETE
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.detailmenu, menu);
        enableMenuItem = menu.findItem(R.id.detailButton);
        return true;
    }


    // Handle button DONE activity
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        Intent intent = new Intent();

        // Get EditText First Name, Last Name, & CWID strings
        String firstString = firstText.getText().toString().trim();
        String lastString = lastText.getText().toString().trim();
        String CWIDString = CWIDText.getText().toString().trim();

        // When DONE is clicked, pass data to DB and output to Main Activity
        if (id == R.id.detailButton) {
            myDB.insertData(firstString, lastString, CWIDString);
            myDB.insertDataCourse(courseString, gradeString, CWIDString);
            }
        // When UPDATE is clicked, call function to update data from DB and output to Main Activity
        else if(id == R.id.updateButton){
            myDB.updateData(firstString, lastString, CWIDString);
        }
        // When DELETE is clicked, call function to delete data from DB and output to Main Activity
        else if(id == R.id.deleteButton){
            myDB.deleteData(CWIDString);
        }
        setResult(RESULT_OK, intent);
        finish();
        return super.onOptionsItemSelected(item);
    }

}
